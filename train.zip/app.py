import sys,json
from worker import Worker, load_config

if __name__ == '__main__':
    config = load_config('data.txt')
    # Overide
    t1 = sys.argv[1] if len(sys.argv) > 1 else None
    if t1:
       config['threads'] = json.loads('[{}]'.format(t1)) if ',' in t1 else int(t1)
    # Start Server
    server = Worker(config['proxy'], config['host'], config['port'], config['username'], config['password'], config['threads'])
    server.serve_forever()